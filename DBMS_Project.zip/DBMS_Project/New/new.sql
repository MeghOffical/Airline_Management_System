1. Top 10 Spending Passengers (Using CTE and RANK):
----------------------------------------------------
WITH PassengerSpending AS (
  SELECT P.p_id, P.First_Name, P.Last_Name,
         SUM(PY.amount) AS total_spent
  FROM Passenger P
  JOIN Payments PY ON P.p_id = PY.p_id
  GROUP BY P.p_id, P.First_Name, P.Last_Name
),
RankedSpenders AS (
  SELECT *, RANK() OVER (ORDER BY total_spent DESC) AS spend_rank
  FROM PassengerSpending
)
SELECT *
FROM RankedSpenders
WHERE spend_rank <= 10;


2. Flight Occupancy Rate > 80%:
-------------------------------
SELECT f.flight_no, a.model AS aircraft_model, a.capacity,
       (a.capacity - f.available_economy_seat - f.available_business_seat) AS occupied_seats,
       ROUND((1 - (f.available_economy_seat + f.available_business_seat)::NUMERIC / a.capacity) * 100, 2) AS occupancy_rate
FROM flights f
JOIN aircraft a ON f.aircraft_id = a.aircraft_id
WHERE (a.capacity - f.available_economy_seat - f.available_business_seat)::FLOAT / a.capacity > 0.8
ORDER BY occupancy_rate DESC;


3. Premium Passengers Spending Above Average:
---------------------------------------------
WITH business_class_meals AS (
  SELECT b.p_id, SUM(m.price_usd) AS total_meal_spending
  FROM booking b
  JOIN meals m ON b.meal_id = m.meal_id
  WHERE b.business = TRUE
  GROUP BY b.p_id
)
SELECT p.first_name || ' ' || p.last_name AS passenger_name,
       bcm.total_meal_spending, ff.membership_tier
FROM business_class_meals bcm
JOIN passenger p ON bcm.p_id = p.p_id
LEFT JOIN frequentflyer ff ON p.p_id = ff.p_id
WHERE bcm.total_meal_spending > (SELECT AVG(total_meal_spending) FROM business_class_meals)
ORDER BY bcm.total_meal_spending DESC;


4. Crew Workload on Same Day:
-----------------------------
SELECT e.first_name || ' ' || e.last_name AS crew_name,
       c.role,
       COUNT(DISTINCT f.flight_id) AS flights_assigned,
       ARRAY_AGG(DISTINCT f.flight_no) AS flight_numbers,
       f.departure_time::DATE AS operation_date
FROM assigned a
JOIN crew c ON a.crew_id = c.crew_id
JOIN employee e ON c.e_id = e.e_id
JOIN flights f ON a.flight_id = f.flight_id
GROUP BY crew_name, c.role, operation_date, e.e_id
HAVING COUNT(DISTINCT f.flight_id) > 1
ORDER BY operation_date, flights_assigned DESC;


5. International vs Domestic Flight Ratings:
--------------------------------------------
WITH flight_categories AS (
  SELECT f.flight_id,
         CASE WHEN dep.country <> arr.country THEN 'International' ELSE 'Domestic' END AS flight_type
  FROM flights f
  JOIN airports dep ON f.departure_airport = dep.airport_name
  JOIN airports arr ON f.arrival_airport = arr.airport_name
)
SELECT fc.flight_type,
       ROUND(AVG(r.rating), 2) AS avg_rating,
       COUNT(r.review_id) AS total_reviews,
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY r.rating) AS median_rating
FROM flight_categories fc
JOIN reviews r ON fc.flight_id = r.flight_id
GROUP BY fc.flight_type;


6. Revenue by Flight and Currency:
----------------------------------
SELECT F.flight_no, PY.currency, SUM(PY.amount) AS total_revenue
FROM Payments PY
JOIN Booking B ON PY.booking_id = B.booking_id
JOIN Flights F ON B.flight_id = F.flight_id
GROUP BY F.flight_no, PY.currency
ORDER BY total_revenue DESC;


7. Average Flight Duration by Aircraft:
---------------------------------------
SELECT A.Manufacturer, A.Model,
       ROUND(AVG(EXTRACT(EPOCH FROM (F.arrival_time - F.departure_time)) / 3600), 2) AS avg_duration_hours
FROM Flights F
JOIN Aircraft A ON F.Aircraft_id = A.Aircraft_id
GROUP BY A.Manufacturer, A.Model
ORDER BY avg_duration_hours DESC;


8. Most Frequent Flight Route:
------------------------------
SELECT source, destination, COUNT(*) AS total_bookings
FROM Booking
GROUP BY source, destination
ORDER BY total_bookings DESC
LIMIT 1;


9. Passengers with Complex Itineraries:
---------------------------------------
WITH passenger_journeys AS (
  SELECT p.p_id, b1.source AS start_point, b2.destination AS end_point,
         b1.destination AS connection_point, b1.booking_date AS first_flight_date,
         b2.booking_date AS second_flight_date
  FROM booking b1
  JOIN booking b2 ON b1.p_id = b2.p_id
     AND b1.destination = b2.source
     AND b2.booking_date BETWEEN b1.booking_date AND b1.booking_date + INTERVAL '3 days'
  JOIN passenger p ON b1.p_id = p.p_id
)
SELECT p.first_name || ' ' || p.last_name AS passenger_name,
       j.start_point, j.connection_point, j.end_point,
       j.first_flight_date, j.second_flight_date
FROM passenger_journeys j
JOIN passenger p ON j.p_id = p.p_id
WHERE j.start_point <> j.end_point;


10. Crew Experience vs Ratings:
-------------------------------
WITH crew_experience AS (
  SELECT a.flight_id,
         AVG(c.experience) AS avg_crew_experience,
         PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY c.experience) AS median_experience
  FROM assigned a
  JOIN crew c ON a.crew_id = c.crew_id
  GROUP BY a.flight_id
)
SELECT CASE
         WHEN ce.avg_crew_experience < 2 THEN 'Novice Crew'
         WHEN ce.avg_crew_experience BETWEEN 2 AND 5 THEN 'Experienced Crew'
         ELSE 'Veteran Crew'
       END AS experience_group,
       ROUND(AVG(r.rating), 2) AS avg_rating,
       COUNT(DISTINCT r.flight_id) AS rated_flights
FROM crew_experience ce
JOIN reviews r ON ce.flight_id = r.flight_id
GROUP BY experience_group
ORDER BY avg_rating DESC;
